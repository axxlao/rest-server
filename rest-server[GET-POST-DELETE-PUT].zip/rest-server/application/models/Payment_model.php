<?php
class Payment_model extends CI_Model
{
    //METHOD GET==============================================
    public function getPayment($id = null)
    {
        if ($id === null) {
            return $this->db->get('tb_payment')->result_array();
        } else {
            return $this->db->get_where('tb_payment', ['id' => $id])->result_array();
        }
    }

    //METHOD DELETE============================================
    public function deletePayment($id)
    {
        $this->db->delete('tb_payment', ['id' => $id]);
        return $this->db->affected_rows();
    }

    //METHOD POST==============================================
    public function createPayment($data)
    {
        $this->db->insert('tb_payment', $data);
        return $this->db->affected_rows();
    }

    //METHOD UPDATE=============================================
    public function updatePayment($data, $id)
    {
        $this->db->update('tb_payment', $data, ['id' => $id]);
        return $this->db->affected_rows();
    }
}
