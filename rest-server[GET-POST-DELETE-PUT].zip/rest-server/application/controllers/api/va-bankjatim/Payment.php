<?php

use Restserver\Libraries\REST_Controller;

defined('BASEPATH') or exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';


class Payment extends REST_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Payment_model', 'payment');

        $this->methods['index_get']['limit'] = 1000;
        $this->methods['index_delete']['limit'] = 1000;
        $this->methods['index_post']['limit'] = 1000;
        $this->methods['index_put']['limit'] = 1000;
    }

    //METHOD GET================================================
    public function index_get()
    {

        $id = $this->get('id');
        if ($id === null) {
            $payment = $this->payment->getPayment();
        } else {
            $payment = $this->payment->getPayment($id);
        }

        if ($payment) {
            $this->response([
                'status' => true,
                'data' => $payment
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'payment id not found !'
            ], REST_Controller::HTTP_NOT_FOUND);
        }
    }

    //METHOD DELETE============================================
    public function index_delete()
    {
        $id = $this->delete('id');

        if ($id === null) {
            $this->response([
                'status' => false,
                'message' => 'provide an payment id !'
            ], REST_Controller::HTTP_BAD_REQUEST);
        } else {
            if ($this->payment->deletePayment($id) > 0) {
                //ok
                $this->response([
                    'status' => true,
                    'id' => $id,
                    'message' => 'payment deleted !'
                ], REST_Controller::HTTP_OK);
            } else {
                //id not found
                $this->response([
                    'status' => false,
                    'message' => 'payment id not found !'
                ], REST_Controller::HTTP_NOT_FOUND);
            }
        }
    }

    //METHOD POST==============================================
    public function index_post()
    {
        $data = [
            'virtual_account' => $this->post('virtual_account'),
            'amount' => $this->post('amount'),
            'reference' => $this->post('reference'),
            'date' => $this->post('date')
        ];

        if ($this->payment->createPayment($data) > 0) {
            $this->response([
                'status' => true,
                'message' => 'new payment has been insert !'
            ], REST_Controller::HTTP_CREATED);
        } else {
            $this->response([
                'status' => false,
                'message' => 'failed to create new data !'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    //METHOD PUT==============================================
    public function index_put()
    {
        $id = $this->put('id');
        $data = [
            'virtual_account' => $this->put('virtual_account'),
            'amount' => $this->put('amount'),
            'reference' => $this->put('reference'),
            'date' => $this->put('date')
        ];

        if ($this->payment->updatePayment($data, $id) > 0) {
            $this->response([
                'status' => true,
                'message' => 'new payment has been updated !'
            ], REST_Controller::HTTP_OK);
        } else {
            $this->response([
                'status' => false,
                'message' => 'failed to update payment !'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}
